$(document).ready(function () {
    $(".owl-carousel").owlCarousel({
        items: 1,
        loop: true,
        center: true,
        nav: true,
        dots: false,
    });
});